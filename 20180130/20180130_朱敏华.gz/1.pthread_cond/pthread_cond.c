#include "func.h"

typedef struct{
	pthread_cond_t cond;
	pthread_mutex_t mutex;
}data;
void* thread_func(void *p)
{
	int ret;
	data* t=(data*)p;
	pthread_mutex_lock(&t->mutex);
	ret=pthread_cond_wait(&t->cond,&t->mutex);
	pthread_mutex_unlock(&t->mutex);
	printf("%d\n",ret);
	pthread_exit(NULL);
}
int main()
{
	pthread_t pthid;
	data t;
	int ret=pthread_cond_init(&t.cond,NULL);
	if(ret!=0)
	{
		printf("pthread_cond_init failed ret=%d\n",ret);
		return -1;
	}
	pthread_mutex_init(&t.mutex,NULL);
	pthread_create(&pthid,NULL,thread_func,&t);
	sleep(5);
	pthread_cond_signal(&t.cond);//发信号，让条件成立
	pthread_join(pthid,NULL);
	printf("I am main thread\n");
	return 0;								
}



