struct text{
	
	int flag;
	char buf[128];

};
